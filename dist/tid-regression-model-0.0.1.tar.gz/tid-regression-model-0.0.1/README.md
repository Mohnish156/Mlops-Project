# Mlops-Project
The creation and deployment of a machine learning model
